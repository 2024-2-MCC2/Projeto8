# ProjetoIMC

Lucas de Lima Gutierrez.

Aplicativo desenvolvido com o propósito de calcular o IMC e, com base nesse valor, exibir a classificação correspondente ao peso (kg).

Os principais desafios envolveram a exibição dinâmica do resultado do IMC e sua classificação, incluindo mensagens motivacionais ou informativas conforme o cálculo. Além disso, foi necessário criar um fluxo de navegação simples e intuitivo entre as telas, permitindo que os usuários calculassem seu IMC com facilidade e retornassem à tela inicial.