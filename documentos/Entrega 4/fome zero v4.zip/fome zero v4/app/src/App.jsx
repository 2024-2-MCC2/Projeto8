import React from 'react';
import { Routes, Route } from 'react-router-dom';
import styled from 'styled-components';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Contato from './pages/Contato'
import Sobre from './pages/Sobre'
import Doar from './pages/Doar'
import Login from './pages/Login'
import GlobalStyles from './components/globalstyle';

const AppContainer = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh; 
`;

const MainContainer = styled.main`
flex: 1;
padding-bottom: 60px;
`

function App() {
  return (
    <AppContainer>
      <GlobalStyles />
      <Header />
      <MainContainer>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/sobre" element={<Sobre />} />
          <Route path="/contato" element={<Contato />} />
          <Route path='/doar' element={<Doar />} />
          <Route path='/login' element={<Login />} />
        </Routes>
      </MainContainer>
      <Footer />
    </AppContainer>
  );
}

export default App;