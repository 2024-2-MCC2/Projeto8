import React from 'react';
import { Link } from 'react-router-dom'
import Home from '../pages/Home';
import Contato from '../pages/Contato'
import Sobre from '../pages/Sobre'
import styled from 'styled-components';
import logo from '../assets/img/logo.png'

const HeaderContainer = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0px 30px;
  margin-top: 0px;
  background-color: #ff8000;
  color: white;
`;

const Nav = styled.nav`
  ul {
    list-style: none;
    display: flex;
    gap: 15px;
    margin: 0;
    padding: 0;
    font-family: 'Arial', sans-serif;
  }

  li {
    display: inline-block;
    transition: 0.2s;
  }
  
  a {
    color: white;
    text-decoration: none;
    &:hover {
      text-decoration: underline;
      transition: 0.2;
    }
  }
`;

const LogoNav = styled.img`
    width:250px;
    height:100px;
`

const Header = () => {
  return (
    <HeaderContainer>
      {/* <LogoLink to='/'> */}
      <Link to='/'><LogoNav src={logo} alt='Logo Fome Zero'></LogoNav></Link>
      {/* </LogoLink> */}
      <Nav>
        <ul>
          <li><Link to='/'> Home </Link></li>
          <li><Link to='/sobre'> Sobre </Link></li>
          <li><Link to='/contato'> Contato </Link></li> 
          <li><Link to='/doar'> Doação </Link></li> 
          <li><Link to='/login'>Login</Link></li>
      </ul>
    </Nav>
    </HeaderContainer >
  );
};

export default Header;