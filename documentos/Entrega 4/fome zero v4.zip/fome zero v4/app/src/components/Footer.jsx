import React from 'react';
import styled from 'styled-components';

const FooterContainer = styled.footer`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background-color: #ff8000;
  color: white;
  font-size: 14px;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  text-align: center;
`;

const CopyRight = styled.p`
  margin: 0;
`;

const SocialLinks = styled.nav`
  ul {
    list-style: none;
    display: flex;
    gap: 15px;
    margin: 0;
    padding: 0;
  }

  a {
    color: white;
    text-decoration: none;
    &:hover {
      text-decoration: underline;
    }
  }
`;

const Footer = () => {
  return (
    <FooterContainer>
      <CopyRight>© 2024 Fome Zero Brasil. Todos os direitos reservados.</CopyRight>
      <SocialLinks>
        <ul>
          <li><a href="#facebook">Facebook</a></li>
          <li><a href="#twitter">Twitter</a></li>
          <li><a href="#instagram">Instagram</a></li>
        </ul>
      </SocialLinks>
    </FooterContainer>
  );
};

export default Footer;
