import { createGlobalStyle } from 'styled-components';

const GlobalStyles = createGlobalStyle`
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  html, body {
    height: 100%;
    overflow-x: hidden; /* Evita rolagem horizontal */
  }

  body {
    background-color: white; /* Cor de fundo do body */
  }
`;

export default GlobalStyles;