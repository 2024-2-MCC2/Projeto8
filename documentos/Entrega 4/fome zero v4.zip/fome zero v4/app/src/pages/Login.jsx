import React, { useState } from 'react';
import styled from 'styled-components';
import { FaUser, FaLock, FaEye, FaEyeSlash } from 'react-icons/fa';

const LoginContainer = styled.div`
  padding: 20px;
  max-width: 600px;
  margin: auto;
  border-radius: 200px;
  font-family: Arial, Helvetica, sans-serif;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  margin: 10px 0 5px;
  font-weight: bold;
`;

const InputWrapper = styled.div`
  display: flex;
  align-items: center;
  margin: 5px 0;
`;

const Input = styled.input`
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  margin-right: 10px;
  flex-grow: 1;
`;

const Button = styled.button`
  margin-top: 10px;
  padding: 10px;
  background-color: #ffa500;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;

  &:hover {
    background-color: #d17300;
  }
`;

const CheckboxWrapper = styled.div`
  margin-top: 10px;
  display: flex;
  align-items: center;
`;

const Lembrar = styled.input`
  margin-right: 5px;
`;

const ShowPasswordToggle = styled.button`
  background: none;
  border: none;
  cursor: pointer;
  margin-left: -50px;
`;

const Login = () => {
  // Estados para email, senha, erro e loading
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [erro, setErro] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErro(''); // Limpa o erro anterior

    try {
      // Envia a requisição para a API de login no back-end
      const response = await axios.post('http://localhost:5000/login', { email, senha });

      // Recebe o token JWT retornado pela API
      const { token } = response.data;

      // Salva o token JWT no localStorage
      localStorage.setItem('token', token);

      // Redireciona ou atualiza o estado da aplicação após o login bem-sucedido
      alert('Login bem-sucedido!');
      
      // Caso você queira redirecionar para outra página após o login:
      // history.push('/dashboard');  // Exemplo se você usar React Router
    } catch (error) {
      // Se algo deu errado, exibe a mensagem de erro
      setErro(error.response?.data?.error || 'Erro no login');
    } finally {
      setLoading(false);
    }
  };

  return (
    <LoginContainer>
      <h1>Login/Cadastro</h1>
      <Form onSubmit={handleSubmit}>
        <div>
          <Label htmlFor="email">Email:</Label>
          <InputWrapper>
            <Input
              type="email"
              id="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <FaUser />
          </InputWrapper>
        </div>

        <div>
          <Label htmlFor="senha">Senha:</Label>
          <InputWrapper>
            <Input
              type={showPassword ? 'text' : 'password'}
              id="senha"
              name="senha"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              required
            />
            <FaLock />
            <ShowPasswordToggle 
              type="button" 
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <FaEyeSlash /> : <FaEye />}
            </ShowPasswordToggle>
          </InputWrapper>
        </div>

        <CheckboxWrapper>
          <Lembrar type="checkbox" />
          Lembrar de mim
        </CheckboxWrapper>

        {/* Exibe mensagem de erro caso haja */}
        {erro && <p style={{ color: 'red' }}>{erro}</p>}

        <Button type="submit" disabled={loading}>
          {loading ? 'Carregando...' : 'Entrar'}
        </Button>
      </Form>
    </LoginContainer>
  );
};

export default Login;