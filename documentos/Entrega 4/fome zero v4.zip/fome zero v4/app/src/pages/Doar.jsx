import React from 'react';
import styled from 'styled-components';

const DoarContainer = styled.div`
  padding: 20px;
  max-width: 600px;
  margin: auto;
`;

const Titulo = styled.h1`
  text-align: center;
  color: #ff8000;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  margin: 10px 0 5px;
  font-weight: bold;
`;

const Input = styled.input`
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
`;

const Button = styled.button`
  margin-top: 10px;
  padding: 10px;
  background-color: #ff8000;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;

  &:hover {
    background-color: #fa9c3f;
  }
`;

const Doar = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Obrigado pela sua doação!");
  };

  return (
    <DoarContainer>
      <Titulo>Faça uma Doação</Titulo>
      <Form onSubmit={handleSubmit}>
        <Label htmlFor="name">Nome:</Label>
        <Input type="text" id="name" name="name" required />

        <Label htmlFor="email">Email:</Label>
        <Input type="email" id="email" name="email" required />

        <Label htmlFor="amount">Valor da Doação:</Label>
        <Input type="number" id="amount" name="amount" required />

        <Button type="submit">Doar</Button>
      </Form>
    </DoarContainer>
  );
};

export default Doar;