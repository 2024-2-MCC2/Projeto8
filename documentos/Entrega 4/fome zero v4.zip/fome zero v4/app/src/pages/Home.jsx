// Home.js
import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import Background from '../assets/img/banner.jpg';
import img1 from '../assets/img/img-1.jpeg';
import img2 from '../assets/img/img-2.jpg'


const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center; /* Centraliza horizontalmente */
  justify-content: center; /* Centraliza verticalmente */
  height: 100vh; /* Altura total da viewport */
  background-image: url(${Background});
  background-size: cover;
  background-position: center;
  margin: 0;
  padding: 0px;
  position: relative; /* Para o posicionamento do botão */
  width: 100%;
`;

const Separar = styled.div`
display: flex;
flex-direction: column;
align-items: center; 
justify-content: center;
margin: 150px 0 0 0;
padding: 300px;
border-radius: 50px;
font-size: 25px;
`

const ButtonWrapper = styled.div`
  padding: 0px;
  margin-right: 100px;
  border-radius: 8px;
  margin-bottom: 20px;
`;

const Button = styled.button`
  margin-bottom: 20px;
  padding: 15px 30px;
  font-size: 20px;
  color: white;
  background-color: orange;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #d17300;
  }
`;

const ContentWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: 20px;
  background-color: #fdc68e;
  
`;

const ParagraphWrapper = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  text-align: center;
  font-size: 16px;
  &:nth-child(2) {
    flex-direction: row-reverse;
  }

  img {
    width: 500px;
    height: auto;
    margin: 0 100px;
  }

  div {
    display: flex;
    flex-direction: column; /* Coloca o título e o parágrafo um embaixo do outro */
  }

  h1 {
    font-size: 30px;
    margin: 10px; /* Remove margens do título */
  }

  p {
    font-size: 20px;
    margin: 50px 100px; /* Remove margens do parágrafo */
  }
`;

const Img1 = styled.image`
  width: 10px; // Defina a largura desejada
  height: auto; // Mantém a proporção da imagem
  max-width: 100%; // Garante que a imagem não exceda o contêiner

  `

const Home = () => {
  return (
    <>
      <Container>
        <Separar>
        <h1>Fome Zero Brasil</h1>
        <p>A fome é urgente, Instituição focada em distribuição de alimentos para escolas públicas,</p>
        <p>familias necessitadas e moradores de rua com fome no Brasil</p>
        <Link to="/doar">
          <Button>Fazer doação</Button>
        </Link>
        </Separar>
        <div>
          <ContentWrapper>
            <ParagraphWrapper>
              <img src={img1} alt="img1" />
              <div>
                <h1>Doe para nossa instituição</h1>
                <p>
                  Todas as doações feitas para a instituição serão utilizadas para compra e confecção de cestas básicas que serão distribuidas para escolas públicas,
                  <br /> familias necessitas, moradores de ruas e comunidades por todo Brasil
                </p>
                <Link to="sobre">
                  <Button>Sobre</Button>
                </Link>
              </div>
            </ParagraphWrapper>
            <ParagraphWrapper>
              <img src={img2} alt="img2" />
              <div>
                <h1>Sua doação ajuda muita gente</h1>
                <p>Com uma doação de qualquer quantia você poderá estar ajudando milhares de familias, crianças e moradores de rua em situação de fome</p>
                <Link to="contato">
                  <Button>Contato</Button>
                </Link>
              </div>
            </ParagraphWrapper>
          </ContentWrapper>
        </div>
      </Container>
    </>
  );
};

export default Home;