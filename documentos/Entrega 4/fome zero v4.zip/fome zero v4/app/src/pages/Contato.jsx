import React from 'react';
import styled from 'styled-components';

const ContatoContainer = styled.div`
  padding: 20px;
  max-width: 600px;
  margin: auto;
  border-radius: 200px;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  margin: 10px 0 5px;
  font-weight: bold;
`;

const Input = styled.input`
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
`;

const Textarea = styled.textarea`
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
`;

const Button = styled.button`
  margin-top: 10px;
  padding: 10px;
  background-color: #ffa500;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;

  &:hover {
    background-color: #d17300;
  }
`;

const Tlf = styled.div`
text-align: center;
margin: 20px;
padding: 10px;
font-family: Arial, Helvetica, sans-serif;
text-shadow: 1cm;
`

const Contato = () => {
    const handleSubmit = (e) => {
        e.preventDefault();
        
        alert("Mensagem enviada!");
    };




    
    return (
        <ContatoContainer>
            <h1>Contato</h1>
            <Form onSubmit={handleSubmit}>
                <Label htmlFor="name">Nome:</Label>
                <Input type="text" id="name" name="name" required />

                <Label htmlFor="email">Email:</Label>
                <Input type="email" id="email" name="email" required />

                <Label htmlFor="message">Mensagem:</Label>
                <Textarea id="message" name="message" rows="3" required />

                <Button type="submit">Enviar</Button>
           <Tlf>
            <p> ou </p>
            <h2>Telefones para contato:</h2>
            <p>
                +55 11 97829-4444 
            </p>
            </Tlf>
            </Form>
        </ContatoContainer>
    );
};

export default Contato;