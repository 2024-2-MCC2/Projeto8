import React from 'react';
import styled from 'styled-components';
import img1 from '../assets/img/lopital.png';
import img2 from '../assets/img/grafico.png';

const Container = styled.div`
  background-color: #fdc68e;
  background-size: cover;
  background-position: center;
  height: 100vh;
  font-size: 30px;
`

const Title = styled.h1`
  text-align: center;
  color: #000000; 
  
`;

const ContentWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: 20px;
  background-color: #fdc68e;
`;

const ParagraphWrapper = styled.div`
  display: flex;
  align-items: center;
  margin: 40px;
  text-align: center;
  font-size: 25px;
  &:nth-child(2) {
    flex-direction: row-reverse;
  }

  img {
    width: 750px;
    height: auto;
    margin: 0 100px;
  }

  div {
    display: flex;
    flex-direction: column; /* Coloca o título e o parágrafo um embaixo do outro */
  }

  h1 {
    font-size: 30px;
    margin: 10px; /* Remove margens do título */
  }

  p {
    font-size: 20px;
    margin: 50px 100px; /* Remove margens do parágrafo */
  }
`;

const Sobre = () => {
  return (
    <Container>
        <ContentWrapper>
        <Title>Fome Zero Brasil</Title>
        <ParagraphWrapper>
        
          Somos uma organização focada em distribuição de alimentos para aqueles
          que são mais vulneráveis, atualmente atuamos principalmente no estado de São Paulo, porém,
          pretendemos atuar e ajudar pessoas necessitadas pelo Brasil inteiro, visto que não é somente em
          São Paulo que temos pessoas em situação de fome, nos ajude a diminuir a fome no Brasil, nós
          distribuimos alimentos para escolas públicas, familias carentes, moradores de rua e comunidades,
          alimentos e cestas básicas fornecidos por meio de doações feitas por você, produzimos alimentos
          em nossos centros para moradores de rua, mas doamos também as cestas básicas para os demais vulneráveis e 
          para aqueles que ainda não tem acesso ao básico.
        </ParagraphWrapper>    
        <ParagraphWrapper>
        <img src={img1} alt="img1" />
          Esse resuldado sugere que, para cada 1,4 pessoas em insegurança alimentar moderada, há 1 pessoa em 
          insegurança alimentar grave baseada pela taxa de raciação que foi considerada. Tendencia crescente de
          insegurança alimentar moderada em relação a insegurança alimentar grave, o que significa que aos poucos 
          todas as 1,4 pessoas estarão em insegurança alimentar grave.
        </ParagraphWrapper>
        <ParagraphWrapper>
          Em 2018, 4,6% da população brasileira sofria de insegurança alimentar grave, de acordo com a Pesquisa de Orçamentos Familiares POF
          Em 2020, 9% da população brasileira sofria de insegurança alimentar grave, de acordo com dados da Rede Penssan. A Organização das Nações Unidas para Agricultura e Alimentação (FAO) reconheceu esses dados como os mais adequados para criar um novo Mapa da Fome no Brasil. 
          A insegurança alimentar se manifesta de forma diferente em diferentes grupos de idade e de renda: 
          Em 2022, a fome dobrou nas famílias com crianças menores de 10 anos, passando de 9,4% em 2020 para 18,1%. 
          Nos domicílios com três ou mais pessoas com até 18 anos de idade, a fome atingiu 25,7%. 
          Nos domicílios apenas com moradores adultos, a segurança alimentar chegou a 47,4%. 
          50,9% dos domicílios com insegurança alimentar moderada ou grave tinham rendimento domiciliar per capita menor do que meio salário mínimo
        </ParagraphWrapper>
        <ParagraphWrapper>
        <img src={img2} alt="img2" />
           Montar o sistema de equações:
           <br/>
          Para x = 2018, temos:
          𝑓(2018) = 𝑎(2018)^2 + 𝑏(2018) + 𝑐=4,6
          <br />
          Para x = 2020, temos:
          𝑓(2020) = 𝑎(2020)^2 + 𝑏(2020) + 𝑐=9
          <br />
          Para x = 2022, temos:
          𝑓(2022) = 𝑎(2022)^2 + 𝑏(2022) + 𝑐=15,5
          <br />
          Essas três equações formam um sistema que podemos resolver para a, b, e c. 
          Substituindo as equações nos valores para 2018, 2020 e 2022, temos:
            <br/>
          2018^2a + 2018b + c = 4,6
            <br/>
          2020^2a + 2020b + c = 9
            <br/>
          2022^2a + 2022b + c = 15,5
          <br/>
          Encontrando os valores de a, b e c, calculamos a derivada de f(x): <br/>
          f′(x) = 2ax + b <br/>
          Para encontrar os pontos críticos, igualamos a derivada a zero: <br/>
          f ′(x) = 0 ⟹ 2ax + b = 0 <br/>
          Após encontrar o ponto crítico, usaremos a segunda derivada para determinar se esse ponto é um máximo ou um mínimo: <br/>
                          f′′(x)=2a<br/>
                         Se f′′(𝑥) maior que 0, temos um ponto minimo.<br/>
                         f′′(x) menor que 0, temos um ponto de máximo.
        </ParagraphWrapper>
      </ContentWrapper>
    </Container>
  );
};

export default Sobre;