const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const port = 5000;

app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',       
  user: 'root',     
  password: '12345678',   
  database: 'seu-banco',   
});

app.post('/login', (req, res) => {
  const { email, senha } = req.body;

  if (!email || !senha) {
    return res.status(400).json({ error: 'Email e senha são obrigatórios' });
  }

  db.query('SELECT * FROM usuarios WHERE email = ?', [email], (err, results) => {
    if (err) return res.status(500).json({ error: 'Erro no servidor' });
    if (results.length === 0) return res.status(404).json({ error: 'Usuário não encontrado' });

    const user = results[0];

    bcrypt.compare(senha, user.senha, (err, isMatch) => {
      if (err) return res.status(500).json({ error: 'Erro ao comparar a senha' });
      if (!isMatch) return res.status(401).json({ error: 'Senha incorreta' });

      const token = jwt.sign({ id: user.id, email: user.email }, 'secreta', { expiresIn: '1h' });

      res.json({ token });
    });
  });
});

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});